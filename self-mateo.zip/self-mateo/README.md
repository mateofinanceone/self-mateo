<p align="center">
<img src="https://raw.githubusercontent.com/LitRHap/self-wa/main/LitRHap/IMG-20210225-WA0563.jpg" width="230" height="230"/>
</p>
<p align="center">
<a href="#"><img title="self-wa" src="https://img.shields.io/badge/Termux Whatsapp Bot-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/LitRHap"><img title="Author" src="https://img.shields.io/badge/Author-LitRHap-red.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/LitRHap/followers"><img title="Followers" src="https://img.shields.io/github/followers/LitRHap?color=blue&style=flat-square"></a>
<a href="https://github.com/LitRHap/self-wa/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/LitRHap/self-wa?color=red&style=flat-square"></a>
<a href="https://github.com/LitRHap/self-wa/network/members"><img title="Forks" src="https://img.shields.io/github/forks/LitRHap/self-wa?color=red&style=flat-square"></a>
<a href="https://github.com/LitRHap/self-wa/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/LitRHap/self-wa?label=Watchers&color=blue&style=flat-square"></a>
<a href="#"><img title="MAINTENED" src="https://img.shields.io/badge/MAINTENED-YES-blue.svg"</a>
</p>

## Clone this project

```bash
> git clone https://github.com/mateofinanceone/self-mateo
```

## Install the dependencies:
Before running the below command, make sure you're in the project directory that
you've just cloned!!

```bash
> cd self-mateo
> npm i
```

### Usage
```bash
> node index.js
```

### Info
```
prefix = z
```

### Features

| Sticker Creator |                Feature           |
| :-----------: | :--------------------------------: |
|       ✅       | Send Photo with Caption          |
|       ✅       | Reply A Photo                    |
|       ✅       | Reply A Video or GIF             |
|       ✅       | Send Video or GIF with Caption   |
|       ✅       | Reply A Sticker ( sticker to image ) |

| Other  |                     Feature                     |
| :------------: | :---------------------------------------------: |
|       ✅        |   Get a random meme             |
|       ✅        |   Text to speech                |
|       ✅        |   Writing feature 				|
|       ✅        |   What Anime Is This 			|
|       ✅        |   Url2Img ( Screeenshot Web )   |
|       ✅        |   Simsimi		                |

| Group  |                     Feature               |
| :-----------: | :--------------------------------: |
|       ✅        |   Tagall/Mentionall member       |
|       ✅        |   Kick Member Group	             |
|       ✅        |   Add Member Group	             |
|       ✅        |   Get List Admins Group          |

| Owner Bot  |                     Feature           |
| :-----------: | :--------------------------------: |
|       ✅        |   Set Prefix                     |
|       ✅        |   Broadcast                      |
|       ✅        |   Clear All Chats                |

### Special Thanks to
* [`adiwajshing/Baileys`](https://github.com/adiwajshing/Baileys)
* [`MitsuGans`](https://github.com/MitsuGans)
* [`Kevin David`]
* [`Bang Garena`]bang OTP nomor malay
* [`LitRHap`](https://instagram.com/litrhap.goat)
* [`Acil`]
* [`Style Cogan`]
